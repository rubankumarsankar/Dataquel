(function($) {
    "use strict";

    

})(jQuery);